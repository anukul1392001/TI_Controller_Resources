namespace GUI_Template
{
    partial class HVLLC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HVLLC));
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_Main = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSetFED = new System.Windows.Forms.Button();
            this.btnSetRED = new System.Windows.Forms.Button();
            this.txtSetFED = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnLLCEnable = new System.Windows.Forms.Button();
            this.txtSetRED = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnCompEnable = new System.Windows.Forms.Button();
            this.lblVGetCH2 = new System.Windows.Forms.Label();
            this.txtGetILed2 = new System.Windows.Forms.TextBox();
            this.btnSetCOMP2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtSetCOMP2 = new System.Windows.Forms.TextBox();
            this.labelasdsad = new System.Windows.Forms.Label();
            this.lblVGetCH1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUnits1 = new System.Windows.Forms.Label();
            this.txtSetCOMP1 = new System.Windows.Forms.TextBox();
            this.btnSetCOMP1 = new System.Windows.Forms.Button();
            this.txtGetILed1 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnSetFEM2 = new System.Windows.Forms.Button();
            this.txtSetFEM2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnSREnable = new System.Windows.Forms.Button();
            this.txtSetREM2 = new System.Windows.Forms.TextBox();
            this.btnSetREM2 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnSetFEM1 = new System.Windows.Forms.Button();
            this.txtSetFEM1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSetREM1 = new System.Windows.Forms.TextBox();
            this.btnSetREM1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSetDgain = new System.Windows.Forms.Button();
            this.txtSetDgain = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnSetIgain = new System.Windows.Forms.Button();
            this.txtSetIgain = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSetPgain = new System.Windows.Forms.TextBox();
            this.btnSetPgain = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtVset = new System.Windows.Forms.TextBox();
            this.lblMinVset = new System.Windows.Forms.Label();
            this.txtGetVout = new System.Windows.Forms.TextBox();
            this.sldrVset = new System.Windows.Forms.TrackBar();
            this.lblMaxVset = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.cmbMainUpdateRate = new System.Windows.Forms.ComboBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.pnlConnect = new System.Windows.Forms.Panel();
            this.btnSetupConnection = new System.Windows.Forms.Button();
            this.MainTimer = new System.Windows.Forms.Timer(this.components);
            this.GraphTimer = new System.Windows.Forms.Timer(this.components);
            this.btnSaveDefaults = new System.Windows.Forms.Button();
            this.btnResetDefaults = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.prbConnectStatus = new System.Windows.Forms.ProgressBar();
            this.pnlLicense = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.btnLicenseDisagree = new System.Windows.Forms.Button();
            this.rtxtLicense = new System.Windows.Forms.RichTextBox();
            this.btnLicenseAgree = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage_Main.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sldrVset)).BeginInit();
            this.pnlLicense.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblStatus
            // 
            this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(44, 467);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(79, 13);
            this.lblStatus.TabIndex = 5;
            this.lblStatus.Text = "Not Connected";
            // 
            // btnConnect
            // 
            this.btnConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConnect.Location = new System.Drawing.Point(441, 430);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(80, 23);
            this.btnConnect.TabIndex = 104;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage_Main);
            this.tabControl1.Location = new System.Drawing.Point(0, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.ShowToolTips = true;
            this.tabControl1.Size = new System.Drawing.Size(534, 421);
            this.tabControl1.TabIndex = 502;
            this.tabControl1.TabStop = false;
            // 
            // tabPage_Main
            // 
            this.tabPage_Main.AutoScroll = true;
            this.tabPage_Main.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage_Main.Controls.Add(this.panel2);
            this.tabPage_Main.Controls.Add(this.panel7);
            this.tabPage_Main.Controls.Add(this.panel6);
            this.tabPage_Main.Controls.Add(this.panel3);
            this.tabPage_Main.Controls.Add(this.label20);
            this.tabPage_Main.Controls.Add(this.panel1);
            this.tabPage_Main.Controls.Add(this.label19);
            this.tabPage_Main.Controls.Add(this.cmbMainUpdateRate);
            this.tabPage_Main.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Main.Name = "tabPage_Main";
            this.tabPage_Main.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Main.Size = new System.Drawing.Size(526, 395);
            this.tabPage_Main.TabIndex = 0;
            this.tabPage_Main.Text = "Main Panel";
            this.tabPage_Main.ToolTipText = "Change voltages and view the status of the target board.";
            this.tabPage_Main.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnSetFED);
            this.panel2.Controls.Add(this.btnSetRED);
            this.panel2.Controls.Add(this.txtSetFED);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.btnLLCEnable);
            this.panel2.Controls.Add(this.txtSetRED);
            this.panel2.Location = new System.Drawing.Point(8, 111);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(167, 119);
            this.panel2.TabIndex = 925;
            // 
            // btnSetFED
            // 
            this.btnSetFED.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetFED.Location = new System.Drawing.Point(124, 85);
            this.btnSetFED.Name = "btnSetFED";
            this.btnSetFED.Size = new System.Drawing.Size(33, 23);
            this.btnSetFED.TabIndex = 6;
            this.btnSetFED.Text = "Set";
            this.btnSetFED.UseVisualStyleBackColor = true;
            this.btnSetFED.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // btnSetRED
            // 
            this.btnSetRED.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetRED.Location = new System.Drawing.Point(124, 50);
            this.btnSetRED.Name = "btnSetRED";
            this.btnSetRED.Size = new System.Drawing.Size(33, 23);
            this.btnSetRED.TabIndex = 4;
            this.btnSetRED.Text = "Set";
            this.btnSetRED.UseVisualStyleBackColor = true;
            this.btnSetRED.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // txtSetFED
            // 
            this.txtSetFED.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetFED.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "FED", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetFED.Location = new System.Drawing.Point(48, 86);
            this.txtSetFED.Name = "txtSetFED";
            this.txtSetFED.Size = new System.Drawing.Size(67, 20);
            this.txtSetFED.TabIndex = 5;
            this.txtSetFED.Text = global::GUI_Template.Properties.Settings.Default.FED;
            this.txtSetFED.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetFED.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetFED.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(10, 55);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 13);
            this.label15.TabIndex = 929;
            this.label15.Tag = "1";
            this.label15.Text = "RED:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(12, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 932;
            this.label8.Tag = "1";
            this.label8.Text = "FED:";
            // 
            // btnLLCEnable
            // 
            this.btnLLCEnable.Location = new System.Drawing.Point(40, 10);
            this.btnLLCEnable.Name = "btnLLCEnable";
            this.btnLLCEnable.Size = new System.Drawing.Size(84, 23);
            this.btnLLCEnable.TabIndex = 2;
            this.btnLLCEnable.Text = "Enable LLC";
            this.btnLLCEnable.UseVisualStyleBackColor = true;
            this.btnLLCEnable.Click += new System.EventHandler(this.btnLLCEnable_Click);
            // 
            // txtSetRED
            // 
            this.txtSetRED.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetRED.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "RED", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetRED.Location = new System.Drawing.Point(48, 51);
            this.txtSetRED.Name = "txtSetRED";
            this.txtSetRED.Size = new System.Drawing.Size(67, 20);
            this.txtSetRED.TabIndex = 3;
            this.txtSetRED.Text = global::GUI_Template.Properties.Settings.Default.RED;
            this.txtSetRED.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetRED.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetRED.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.btnCompEnable);
            this.panel7.Controls.Add(this.lblVGetCH2);
            this.panel7.Controls.Add(this.txtGetILed2);
            this.panel7.Controls.Add(this.btnSetCOMP2);
            this.panel7.Controls.Add(this.label11);
            this.panel7.Controls.Add(this.txtSetCOMP2);
            this.panel7.Controls.Add(this.labelasdsad);
            this.panel7.Controls.Add(this.lblVGetCH1);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Controls.Add(this.lblUnits1);
            this.panel7.Controls.Add(this.txtSetCOMP1);
            this.panel7.Controls.Add(this.btnSetCOMP1);
            this.panel7.Controls.Add(this.txtGetILed1);
            this.panel7.Location = new System.Drawing.Point(354, 111);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(167, 244);
            this.panel7.TabIndex = 924;
            // 
            // btnCompEnable
            // 
            this.btnCompEnable.Location = new System.Drawing.Point(40, 10);
            this.btnCompEnable.Name = "btnCompEnable";
            this.btnCompEnable.Size = new System.Drawing.Size(84, 23);
            this.btnCompEnable.TabIndex = 22;
            this.btnCompEnable.Text = "Enable Comp";
            this.btnCompEnable.UseVisualStyleBackColor = true;
            this.btnCompEnable.Click += new System.EventHandler(this.GenericEventHandler_SetBtn_BtnClick);
            // 
            // lblVGetCH2
            // 
            this.lblVGetCH2.AutoSize = true;
            this.lblVGetCH2.Location = new System.Drawing.Point(5, 178);
            this.lblVGetCH2.Name = "lblVGetCH2";
            this.lblVGetCH2.Size = new System.Drawing.Size(68, 13);
            this.lblVGetCH2.TabIndex = 721;
            this.lblVGetCH2.Tag = "2";
            this.lblVGetCH2.Text = "SR2 Current:";
            // 
            // txtGetILed2
            // 
            this.txtGetILed2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.txtGetILed2.Location = new System.Drawing.Point(75, 174);
            this.txtGetILed2.Name = "txtGetILed2";
            this.txtGetILed2.ReadOnly = true;
            this.txtGetILed2.Size = new System.Drawing.Size(67, 20);
            this.txtGetILed2.TabIndex = 37;
            this.txtGetILed2.TabStop = false;
            this.txtGetILed2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnSetCOMP2
            // 
            this.btnSetCOMP2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetCOMP2.Location = new System.Drawing.Point(126, 85);
            this.btnSetCOMP2.Name = "btnSetCOMP2";
            this.btnSetCOMP2.Size = new System.Drawing.Size(33, 23);
            this.btnSetCOMP2.TabIndex = 26;
            this.btnSetCOMP2.Text = "Set";
            this.btnSetCOMP2.UseVisualStyleBackColor = true;
            this.btnSetCOMP2.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(146, 178);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 13);
            this.label11.TabIndex = 812;
            this.label11.Text = "A";
            // 
            // txtSetCOMP2
            // 
            this.txtSetCOMP2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetCOMP2.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "COMP2", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetCOMP2.Location = new System.Drawing.Point(49, 86);
            this.txtSetCOMP2.Name = "txtSetCOMP2";
            this.txtSetCOMP2.Size = new System.Drawing.Size(67, 20);
            this.txtSetCOMP2.TabIndex = 25;
            this.txtSetCOMP2.Text = global::GUI_Template.Properties.Settings.Default.COMP2;
            this.txtSetCOMP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetCOMP2.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetCOMP2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // labelasdsad
            // 
            this.labelasdsad.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelasdsad.AutoSize = true;
            this.labelasdsad.BackColor = System.Drawing.Color.White;
            this.labelasdsad.Location = new System.Drawing.Point(2, 90);
            this.labelasdsad.Name = "labelasdsad";
            this.labelasdsad.Size = new System.Drawing.Size(47, 13);
            this.labelasdsad.TabIndex = 920;
            this.labelasdsad.Tag = "1";
            this.labelasdsad.Text = "COMP2:";
            // 
            // lblVGetCH1
            // 
            this.lblVGetCH1.AutoSize = true;
            this.lblVGetCH1.BackColor = System.Drawing.Color.White;
            this.lblVGetCH1.Location = new System.Drawing.Point(5, 143);
            this.lblVGetCH1.Name = "lblVGetCH1";
            this.lblVGetCH1.Size = new System.Drawing.Size(68, 13);
            this.lblVGetCH1.TabIndex = 720;
            this.lblVGetCH1.Tag = "1";
            this.lblVGetCH1.Text = "SR1 Current:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 920;
            this.label1.Tag = "1";
            this.label1.Text = "COMP1:";
            // 
            // lblUnits1
            // 
            this.lblUnits1.AutoSize = true;
            this.lblUnits1.Location = new System.Drawing.Point(146, 143);
            this.lblUnits1.Name = "lblUnits1";
            this.lblUnits1.Size = new System.Drawing.Size(14, 13);
            this.lblUnits1.TabIndex = 811;
            this.lblUnits1.Text = "A";
            // 
            // txtSetCOMP1
            // 
            this.txtSetCOMP1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetCOMP1.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "COMP1", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetCOMP1.Location = new System.Drawing.Point(49, 51);
            this.txtSetCOMP1.Name = "txtSetCOMP1";
            this.txtSetCOMP1.Size = new System.Drawing.Size(67, 20);
            this.txtSetCOMP1.TabIndex = 23;
            this.txtSetCOMP1.Text = global::GUI_Template.Properties.Settings.Default.COMP1;
            this.txtSetCOMP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetCOMP1.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetCOMP1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // btnSetCOMP1
            // 
            this.btnSetCOMP1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetCOMP1.Location = new System.Drawing.Point(126, 50);
            this.btnSetCOMP1.Name = "btnSetCOMP1";
            this.btnSetCOMP1.Size = new System.Drawing.Size(33, 23);
            this.btnSetCOMP1.TabIndex = 24;
            this.btnSetCOMP1.Text = "Set";
            this.btnSetCOMP1.UseVisualStyleBackColor = true;
            this.btnSetCOMP1.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // txtGetILed1
            // 
            this.txtGetILed1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.txtGetILed1.Location = new System.Drawing.Point(75, 139);
            this.txtGetILed1.Name = "txtGetILed1";
            this.txtGetILed1.ReadOnly = true;
            this.txtGetILed1.Size = new System.Drawing.Size(67, 20);
            this.txtGetILed1.TabIndex = 32;
            this.txtGetILed1.TabStop = false;
            this.txtGetILed1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.btnSetFEM2);
            this.panel6.Controls.Add(this.txtSetFEM2);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.btnSREnable);
            this.panel6.Controls.Add(this.txtSetREM2);
            this.panel6.Controls.Add(this.btnSetREM2);
            this.panel6.Controls.Add(this.label14);
            this.panel6.Controls.Add(this.btnSetFEM1);
            this.panel6.Controls.Add(this.txtSetFEM1);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.txtSetREM1);
            this.panel6.Controls.Add(this.btnSetREM1);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Location = new System.Drawing.Point(181, 111);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(167, 244);
            this.panel6.TabIndex = 923;
            // 
            // btnSetFEM2
            // 
            this.btnSetFEM2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetFEM2.Location = new System.Drawing.Point(126, 173);
            this.btnSetFEM2.Name = "btnSetFEM2";
            this.btnSetFEM2.Size = new System.Drawing.Size(33, 23);
            this.btnSetFEM2.TabIndex = 21;
            this.btnSetFEM2.Text = "Set";
            this.btnSetFEM2.UseVisualStyleBackColor = true;
            this.btnSetFEM2.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // txtSetFEM2
            // 
            this.txtSetFEM2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetFEM2.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "FEM2", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetFEM2.Location = new System.Drawing.Point(50, 174);
            this.txtSetFEM2.Name = "txtSetFEM2";
            this.txtSetFEM2.Size = new System.Drawing.Size(67, 20);
            this.txtSetFEM2.TabIndex = 20;
            this.txtSetFEM2.Text = global::GUI_Template.Properties.Settings.Default.FEM2;
            this.txtSetFEM2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetFEM2.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetFEM2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(7, 178);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 926;
            this.label12.Tag = "1";
            this.label12.Text = "FEM2:";
            // 
            // btnSREnable
            // 
            this.btnSREnable.Location = new System.Drawing.Point(40, 10);
            this.btnSREnable.Name = "btnSREnable";
            this.btnSREnable.Size = new System.Drawing.Size(84, 23);
            this.btnSREnable.TabIndex = 13;
            this.btnSREnable.Text = "Enable SR";
            this.btnSREnable.UseVisualStyleBackColor = true;
            this.btnSREnable.Click += new System.EventHandler(this.btnSREnable_Click);
            // 
            // txtSetREM2
            // 
            this.txtSetREM2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetREM2.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "REM2", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetREM2.Location = new System.Drawing.Point(50, 139);
            this.txtSetREM2.Name = "txtSetREM2";
            this.txtSetREM2.Size = new System.Drawing.Size(67, 20);
            this.txtSetREM2.TabIndex = 18;
            this.txtSetREM2.Text = global::GUI_Template.Properties.Settings.Default.REM2;
            this.txtSetREM2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetREM2.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetREM2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // btnSetREM2
            // 
            this.btnSetREM2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetREM2.Location = new System.Drawing.Point(126, 138);
            this.btnSetREM2.Name = "btnSetREM2";
            this.btnSetREM2.Size = new System.Drawing.Size(33, 23);
            this.btnSetREM2.TabIndex = 19;
            this.btnSetREM2.Text = "Set";
            this.btnSetREM2.UseVisualStyleBackColor = true;
            this.btnSetREM2.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(5, 143);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 923;
            this.label14.Tag = "1";
            this.label14.Text = "REM2:";
            // 
            // btnSetFEM1
            // 
            this.btnSetFEM1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetFEM1.Location = new System.Drawing.Point(126, 85);
            this.btnSetFEM1.Name = "btnSetFEM1";
            this.btnSetFEM1.Size = new System.Drawing.Size(33, 23);
            this.btnSetFEM1.TabIndex = 17;
            this.btnSetFEM1.Text = "Set";
            this.btnSetFEM1.UseVisualStyleBackColor = true;
            this.btnSetFEM1.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // txtSetFEM1
            // 
            this.txtSetFEM1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetFEM1.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "FEM1", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetFEM1.Location = new System.Drawing.Point(50, 86);
            this.txtSetFEM1.Name = "txtSetFEM1";
            this.txtSetFEM1.Size = new System.Drawing.Size(67, 20);
            this.txtSetFEM1.TabIndex = 16;
            this.txtSetFEM1.Text = global::GUI_Template.Properties.Settings.Default.FEM1;
            this.txtSetFEM1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetFEM1.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetFEM1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(7, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 917;
            this.label2.Tag = "1";
            this.label2.Text = "FEM1:";
            // 
            // txtSetREM1
            // 
            this.txtSetREM1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetREM1.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "REM1", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetREM1.Location = new System.Drawing.Point(50, 51);
            this.txtSetREM1.Name = "txtSetREM1";
            this.txtSetREM1.Size = new System.Drawing.Size(67, 20);
            this.txtSetREM1.TabIndex = 14;
            this.txtSetREM1.Text = global::GUI_Template.Properties.Settings.Default.REM1;
            this.txtSetREM1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetREM1.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetREM1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // btnSetREM1
            // 
            this.btnSetREM1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetREM1.Location = new System.Drawing.Point(126, 50);
            this.btnSetREM1.Name = "btnSetREM1";
            this.btnSetREM1.Size = new System.Drawing.Size(33, 23);
            this.btnSetREM1.TabIndex = 15;
            this.btnSetREM1.Text = "Set";
            this.btnSetREM1.UseVisualStyleBackColor = true;
            this.btnSetREM1.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(5, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 720;
            this.label3.Tag = "1";
            this.label3.Text = "REM1:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnSetDgain);
            this.panel3.Controls.Add(this.txtSetDgain);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.btnSetIgain);
            this.panel3.Controls.Add(this.txtSetIgain);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.txtSetPgain);
            this.panel3.Controls.Add(this.btnSetPgain);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(8, 236);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(167, 119);
            this.panel3.TabIndex = 813;
            // 
            // btnSetDgain
            // 
            this.btnSetDgain.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetDgain.Location = new System.Drawing.Point(126, 82);
            this.btnSetDgain.Name = "btnSetDgain";
            this.btnSetDgain.Size = new System.Drawing.Size(33, 23);
            this.btnSetDgain.TabIndex = 12;
            this.btnSetDgain.Text = "Set";
            this.btnSetDgain.UseVisualStyleBackColor = true;
            this.btnSetDgain.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // txtSetDgain
            // 
            this.txtSetDgain.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetDgain.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "Dgain", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetDgain.Location = new System.Drawing.Point(50, 82);
            this.txtSetDgain.Name = "txtSetDgain";
            this.txtSetDgain.Size = new System.Drawing.Size(67, 20);
            this.txtSetDgain.TabIndex = 11;
            this.txtSetDgain.Text = global::GUI_Template.Properties.Settings.Default.Dgain;
            this.txtSetDgain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetDgain.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetDgain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(2, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 920;
            this.label10.Tag = "1";
            this.label10.Text = "D Gain:";
            // 
            // btnSetIgain
            // 
            this.btnSetIgain.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetIgain.Location = new System.Drawing.Point(126, 48);
            this.btnSetIgain.Name = "btnSetIgain";
            this.btnSetIgain.Size = new System.Drawing.Size(33, 23);
            this.btnSetIgain.TabIndex = 10;
            this.btnSetIgain.Text = "Set";
            this.btnSetIgain.UseVisualStyleBackColor = true;
            this.btnSetIgain.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // txtSetIgain
            // 
            this.txtSetIgain.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetIgain.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "Igain", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetIgain.Location = new System.Drawing.Point(50, 48);
            this.txtSetIgain.Name = "txtSetIgain";
            this.txtSetIgain.Size = new System.Drawing.Size(67, 20);
            this.txtSetIgain.TabIndex = 9;
            this.txtSetIgain.Text = global::GUI_Template.Properties.Settings.Default.Igain;
            this.txtSetIgain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetIgain.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetIgain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(7, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 917;
            this.label9.Tag = "1";
            this.label9.Text = "I Gain:";
            // 
            // txtSetPgain
            // 
            this.txtSetPgain.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSetPgain.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "Pgain", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtSetPgain.Location = new System.Drawing.Point(50, 13);
            this.txtSetPgain.Name = "txtSetPgain";
            this.txtSetPgain.Size = new System.Drawing.Size(67, 20);
            this.txtSetPgain.TabIndex = 7;
            this.txtSetPgain.Text = global::GUI_Template.Properties.Settings.Default.Pgain;
            this.txtSetPgain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSetPgain.TextChanged += new System.EventHandler(this.GenericEventHandler_SetTxt_TxtChanged);
            this.txtSetPgain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetTxt_TxtKeyDown);
            // 
            // btnSetPgain
            // 
            this.btnSetPgain.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSetPgain.Location = new System.Drawing.Point(126, 10);
            this.btnSetPgain.Name = "btnSetPgain";
            this.btnSetPgain.Size = new System.Drawing.Size(33, 23);
            this.btnSetPgain.TabIndex = 8;
            this.btnSetPgain.Text = "Set";
            this.btnSetPgain.UseVisualStyleBackColor = true;
            this.btnSetPgain.Click += new System.EventHandler(this.GenericEventHandler_SetTxt_BtnClick);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(3, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 720;
            this.label7.Tag = "1";
            this.label7.Text = "P Gain:";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(506, 370);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(12, 13);
            this.label20.TabIndex = 820;
            this.label20.Text = "s";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.txtVset);
            this.panel1.Controls.Add(this.lblMinVset);
            this.panel1.Controls.Add(this.txtGetVout);
            this.panel1.Controls.Add(this.sldrVset);
            this.panel1.Controls.Add(this.lblMaxVset);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(515, 99);
            this.panel1.TabIndex = 900;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(11, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 13);
            this.label5.TabIndex = 917;
            this.label5.Tag = "1";
            this.label5.Text = "Output Target:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(6, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 916;
            this.label4.Tag = "1";
            this.label4.Text = "Output Voltage:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(394, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(113, 47);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 914;
            this.pictureBox1.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(163, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(14, 13);
            this.label23.TabIndex = 801;
            this.label23.Text = "V";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(163, 60);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(14, 13);
            this.label13.TabIndex = 802;
            this.label13.Text = "V";
            // 
            // txtVset
            // 
            this.txtVset.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::GUI_Template.Properties.Settings.Default, "Vout", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtVset.Location = new System.Drawing.Point(93, 56);
            this.txtVset.Name = "txtVset";
            this.txtVset.Size = new System.Drawing.Size(64, 20);
            this.txtVset.TabIndex = 1;
            this.txtVset.Text = global::GUI_Template.Properties.Settings.Default.Vout;
            this.txtVset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtVset.TextChanged += new System.EventHandler(this.GenericEventHandler_SetSldr_TxtChanged);
            this.txtVset.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GenericEventHandler_SetSldr_TxtKeyDown);
            // 
            // lblMinVset
            // 
            this.lblMinVset.AutoSize = true;
            this.lblMinVset.Location = new System.Drawing.Point(188, 60);
            this.lblMinVset.Name = "lblMinVset";
            this.lblMinVset.Size = new System.Drawing.Size(13, 13);
            this.lblMinVset.TabIndex = 44;
            this.lblMinVset.Text = "0";
            // 
            // txtGetVout
            // 
            this.txtGetVout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.txtGetVout.Location = new System.Drawing.Point(93, 17);
            this.txtGetVout.Name = "txtGetVout";
            this.txtGetVout.ReadOnly = true;
            this.txtGetVout.Size = new System.Drawing.Size(64, 20);
            this.txtGetVout.TabIndex = 501;
            this.txtGetVout.TabStop = false;
            this.txtGetVout.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // sldrVset
            // 
            this.sldrVset.LargeChange = 15;
            this.sldrVset.Location = new System.Drawing.Point(206, 44);
            this.sldrVset.Margin = new System.Windows.Forms.Padding(2);
            this.sldrVset.Maximum = 32768;
            this.sldrVset.Name = "sldrVset";
            this.sldrVset.Size = new System.Drawing.Size(141, 45);
            this.sldrVset.SmallChange = 2;
            this.sldrVset.TabIndex = 2;
            this.sldrVset.TabStop = false;
            this.sldrVset.TickFrequency = 4096;
            this.sldrVset.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.sldrVset.Scroll += new System.EventHandler(this.GenericEventHandler_SetSldr_SldrScroll);
            // 
            // lblMaxVset
            // 
            this.lblMaxVset.AutoSize = true;
            this.lblMaxVset.Location = new System.Drawing.Point(352, 60);
            this.lblMaxVset.Name = "lblMaxVset";
            this.lblMaxVset.Size = new System.Drawing.Size(28, 13);
            this.lblMaxVset.TabIndex = 43;
            this.lblMaxVset.Text = "14.0";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(379, 369);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 13);
            this.label19.TabIndex = 107;
            this.label19.Text = "Update Rate:";
            // 
            // cmbMainUpdateRate
            // 
            this.cmbMainUpdateRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbMainUpdateRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMainUpdateRate.Items.AddRange(new object[] {
            "---",
            "1.00",
            "1.50",
            "3.00"});
            this.cmbMainUpdateRate.Location = new System.Drawing.Point(456, 366);
            this.cmbMainUpdateRate.Name = "cmbMainUpdateRate";
            this.cmbMainUpdateRate.Size = new System.Drawing.Size(49, 21);
            this.cmbMainUpdateRate.TabIndex = 100;
            this.cmbMainUpdateRate.SelectedIndexChanged += new System.EventHandler(this.cmbMainUpdateRate_SelectedIndexChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 462);
            this.statusStrip1.Margin = new System.Windows.Forms.Padding(2);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(535, 22);
            this.statusStrip1.TabIndex = 13;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // pnlConnect
            // 
            this.pnlConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlConnect.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlConnect.Location = new System.Drawing.Point(20, 467);
            this.pnlConnect.Name = "pnlConnect";
            this.pnlConnect.Size = new System.Drawing.Size(14, 13);
            this.pnlConnect.TabIndex = 15;
            // 
            // btnSetupConnection
            // 
            this.btnSetupConnection.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetupConnection.Location = new System.Drawing.Point(328, 430);
            this.btnSetupConnection.Name = "btnSetupConnection";
            this.btnSetupConnection.Size = new System.Drawing.Size(107, 23);
            this.btnSetupConnection.TabIndex = 103;
            this.btnSetupConnection.Text = "Setup Connection";
            this.btnSetupConnection.UseVisualStyleBackColor = true;
            this.btnSetupConnection.Click += new System.EventHandler(this.btnSetupConnection_Click);
            // 
            // MainTimer
            // 
            this.MainTimer.Interval = 1000;
            this.MainTimer.Tick += new System.EventHandler(this.MainTimer_Tick);
            // 
            // GraphTimer
            // 
            this.GraphTimer.Interval = 3000;
            // 
            // btnSaveDefaults
            // 
            this.btnSaveDefaults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSaveDefaults.Location = new System.Drawing.Point(8, 430);
            this.btnSaveDefaults.Name = "btnSaveDefaults";
            this.btnSaveDefaults.Size = new System.Drawing.Size(115, 23);
            this.btnSaveDefaults.TabIndex = 101;
            this.btnSaveDefaults.Text = "Save Configuration";
            this.btnSaveDefaults.UseVisualStyleBackColor = true;
            this.btnSaveDefaults.Click += new System.EventHandler(this.btnSaveDefaults_Click);
            // 
            // btnResetDefaults
            // 
            this.btnResetDefaults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnResetDefaults.Location = new System.Drawing.Point(128, 430);
            this.btnResetDefaults.Name = "btnResetDefaults";
            this.btnResetDefaults.Size = new System.Drawing.Size(65, 23);
            this.btnResetDefaults.TabIndex = 102;
            this.btnResetDefaults.Text = "Reset";
            this.btnResetDefaults.UseVisualStyleBackColor = true;
            this.btnResetDefaults.Click += new System.EventHandler(this.btnResetDefaults_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 10000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.ReshowDelay = 100;
            // 
            // prbConnectStatus
            // 
            this.prbConnectStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.prbConnectStatus.Location = new System.Drawing.Point(441, 466);
            this.prbConnectStatus.Name = "prbConnectStatus";
            this.prbConnectStatus.Size = new System.Drawing.Size(66, 16);
            this.prbConnectStatus.TabIndex = 16;
            // 
            // pnlLicense
            // 
            this.pnlLicense.BackColor = System.Drawing.SystemColors.Control;
            this.pnlLicense.Controls.Add(this.label6);
            this.pnlLicense.Controls.Add(this.label53);
            this.pnlLicense.Controls.Add(this.label52);
            this.pnlLicense.Controls.Add(this.label47);
            this.pnlLicense.Controls.Add(this.btnLicenseDisagree);
            this.pnlLicense.Controls.Add(this.rtxtLicense);
            this.pnlLicense.Controls.Add(this.btnLicenseAgree);
            this.pnlLicense.Location = new System.Drawing.Point(0, 1);
            this.pnlLicense.Name = "pnlLicense";
            this.pnlLicense.Size = new System.Drawing.Size(534, 483);
            this.pnlLicense.TabIndex = 503;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(37, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(197, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "if you agree with its terms and conditions";
            // 
            // label53
            // 
            this.label53.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(22, 427);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(236, 13);
            this.label53.TabIndex = 5;
            this.label53.Text = "I have read the above terms and conditions and:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(22, 64);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(297, 13);
            this.label52.TabIndex = 4;
            this.label52.Text = "Please read the license agreement below and click \"I Agree\" ";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(14, 21);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(304, 36);
            this.label47.TabIndex = 3;
            this.label47.Text = "TI License Agreement";
            // 
            // btnLicenseDisagree
            // 
            this.btnLicenseDisagree.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnLicenseDisagree.Location = new System.Drawing.Point(126, 448);
            this.btnLicenseDisagree.Name = "btnLicenseDisagree";
            this.btnLicenseDisagree.Size = new System.Drawing.Size(130, 23);
            this.btnLicenseDisagree.TabIndex = 2;
            this.btnLicenseDisagree.Text = "I Disagree";
            this.btnLicenseDisagree.UseVisualStyleBackColor = true;
            this.btnLicenseDisagree.Click += new System.EventHandler(this.btnLicenseDisagree_Click);
            // 
            // rtxtLicense
            // 
            this.rtxtLicense.Location = new System.Drawing.Point(7, 112);
            this.rtxtLicense.Name = "rtxtLicense";
            this.rtxtLicense.Size = new System.Drawing.Size(518, 302);
            this.rtxtLicense.TabIndex = 1;
            this.rtxtLicense.Text = global::GUI_Template.Properties.Resources.String1;
            // 
            // btnLicenseAgree
            // 
            this.btnLicenseAgree.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnLicenseAgree.Location = new System.Drawing.Point(267, 448);
            this.btnLicenseAgree.Name = "btnLicenseAgree";
            this.btnLicenseAgree.Size = new System.Drawing.Size(130, 23);
            this.btnLicenseAgree.TabIndex = 0;
            this.btnLicenseAgree.Text = "I Agree";
            this.btnLicenseAgree.UseVisualStyleBackColor = true;
            this.btnLicenseAgree.Click += new System.EventHandler(this.btnLicenseAgree_Click);
            // 
            // HVLLC
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(535, 484);
            this.Controls.Add(this.pnlLicense);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.prbConnectStatus);
            this.Controls.Add(this.btnSaveDefaults);
            this.Controls.Add(this.btnSetupConnection);
            this.Controls.Add(this.btnResetDefaults);
            this.Controls.Add(this.pnlConnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "HVLLC";
            this.Text = "Texas Instruments - HV LLC Resonant EVM";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TwoChannelBuck_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.tabPage_Main.ResumeLayout(false);
            this.tabPage_Main.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sldrVset)).EndInit();
            this.pnlLicense.ResumeLayout(false);
            this.pnlLicense.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_Main;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel pnlConnect;
        private System.Windows.Forms.Button btnSetupConnection;
        private System.Windows.Forms.Timer GraphTimer;
        private System.Windows.Forms.TextBox txtGetVout;
        public System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Timer MainTimer;
        private System.Windows.Forms.Button btnSaveDefaults;
        private System.Windows.Forms.Button btnResetDefaults;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ProgressBar prbConnectStatus;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmbMainUpdateRate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TrackBar sldrVset;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtVset;
        private System.Windows.Forms.Label lblMinVset;
        private System.Windows.Forms.Label lblMaxVset;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel pnlLicense;
        private System.Windows.Forms.Button btnLicenseAgree;
        private System.Windows.Forms.RichTextBox rtxtLicense;
        private System.Windows.Forms.Button btnLicenseDisagree;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.Button btnSetPgain;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Button btnLLCEnable;
        private System.Windows.Forms.TextBox txtSetPgain;
        public System.Windows.Forms.Button btnSREnable;
        private System.Windows.Forms.Label lblVGetCH2;
        private System.Windows.Forms.TextBox txtGetILed2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblVGetCH1;
        private System.Windows.Forms.Label lblUnits1;
        private System.Windows.Forms.TextBox txtGetILed1;
        public System.Windows.Forms.Button btnSetDgain;
        private System.Windows.Forms.TextBox txtSetDgain;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.Button btnSetIgain;
        private System.Windows.Forms.TextBox txtSetIgain;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.Button btnSetCOMP2;
        private System.Windows.Forms.TextBox txtSetCOMP2;
        private System.Windows.Forms.Label labelasdsad;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.Button btnSetCOMP1;
        private System.Windows.Forms.TextBox txtSetCOMP1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button btnSetFEM1;
        private System.Windows.Forms.TextBox txtSetFEM1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSetREM1;
        public System.Windows.Forms.Button btnSetREM1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Button btnSetFED;
        private System.Windows.Forms.TextBox txtSetFED;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSetRED;
        public System.Windows.Forms.Button btnSetRED;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.Button btnSetFEM2;
        private System.Windows.Forms.TextBox txtSetFEM2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSetREM2;
        public System.Windows.Forms.Button btnSetREM2;
        private System.Windows.Forms.Label label14;
        public System.Windows.Forms.Button btnCompEnable;
        private System.Windows.Forms.Panel panel2;
    }
}

