//----------------------------------------------------------------------------------
//	FILE:			HVLLC-Main.C
//
//	Description:	Half-Bridge LLC Resonant DC/DC Converter with Synchronous Rectification
//
//	Version: 		1.0
//
//  Target:  		TMS320F2802x (PiccoloA), 
//
//----------------------------------------------------------------------------------
//  Copyright Texas Instruments � 2004-2010
//----------------------------------------------------------------------------------
//  Revision History:
//----------------------------------------------------------------------------------
//  Date	  | Description / Status
//----------------------------------------------------------------------------------
// May 15, 2011  - Release 1.0 (DC)
//----------------------------------------------------------------------------------
//
// PLEASE READ - Useful notes about this Project

// Although this project is made up of several files, the most important ones are:
//	 "HVLLC-Main.C"	- this file
//		- Application Initialization, Peripheral config,
//		- Application management
//		- Slower background code loops and Task scheduling
//	 "HVLLC-DevInit_F28xxx.C
//		- Device Initialization, e.g. Clock, PLL, WD, GPIO mapping
//		- Peripheral clock enables
//		- DevInit file will differ per each F28xxx device series, e.g. F280x, F2833x,
//	 "HVLLC-DPL-ISR.asm
//		- Assembly level library Macros and any cycle critical functions are found here
//	 "HVLLC-Settings.h"
//		- Global defines (settings) project selections are found here
//		- This file is referenced by both C and ASM files.
//
// Code is made up of sections, e.g. "FUNCTION PROTOTYPES", "VARIABLE DECLARATIONS" ,..etc
//	each section has FRAMEWORK and USER areas.
//  FRAMEWORK areas provide useful ready made "infrastructure" code which for the most part
//	does not need modification, e.g. Task scheduling, ISR call, GUI interface support,...etc
//  USER areas have functional example code which can be modified by USER to fit their appl.
//
// Code can be compiled with various build options (Incremental Builds IBx), these
//  options are selected in file "HVLLC-Settings.h".  Note: "Rebuild All" compile
//  tool bar button must be used if this file is modified.
//----------------------------------------------------------------------------------
#include "PeripheralHeaderIncludes.h"
#include "DSP2802x_EPWM_defines.h"		
#include "HVLLC-Settings.h"
		
#include "DPlib.h"	
#include "IQmathLib.h"
#include <math.h>

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// FUNCTION PROTOTYPES
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Add protoypes of functions being used in the project here 
extern interrupt void CNTL_ISR(void);
extern interrupt void PWM_ISR(void);

void DeviceInit(void);
#ifdef FLASH		
	void InitFlash();
#endif
void MemCopy();
void SCIA_Init();
void SerialHostComms();

//-------------------------------- DPLIB --------------------------------------------
void PWM_ComplPairDB_CNF(int16 n, int16 period, int16 mode, int16 phase);
void PWM_ComplPairDB_UpdateDB(int16 n, int16 dbRED, int16 dbFED);
void PWM_1ch_UpCntDB_CNF(int16 n, int16 period, int16 mode, int16 phase);
void PWM_1ch_UpCntDB_UpdateDB(int16 n, int16 dbRED, int16 dbFED);
void PWM_1ch_UpCntDB_Compl_CNF(int16 n, int16 period, int16 mode, int16 phase);
void PWM_1ch_UpCntDB_Compl_UpdateDB(int16 n, int16 dbRED, int16 dbFED);
void PWM_1ch_CNF(int16 n, int16 period, int16 mode, int16 phase);
void ADC_SOC_CNF(int ChSel[], int TrigSel[], int ACQPS[], int IntChSel, int mode);

// -------------------------------- FRAMEWORK --------------------------------------
// State Machine function prototypes
//----------------------------------------------------------------------------------
// Alpha states
void A0(void);	//state A0
void B0(void);	//state B0
void C0(void);	//state C0

// A branch states
void A1(void);	//state A1
void A2(void);	//state A2

// B branch states
void B1(void);	//state B1
void B2(void);	//state B2

// C branch states
void C1(void);	//state C1

// Variable declarations
void (*Alpha_State_Ptr)(void);	// Base States pointer
void (*A_Task_Ptr)(void);		// State pointer A branch
void (*B_Task_Ptr)(void);		// State pointer B branch
void (*C_Task_Ptr)(void);		// State pointer C branch
//----------------------------------------------------------------------------------

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// VARIABLE DECLARATIONS - GENERAL
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// -------------------------------- FRAMEWORK --------------------------------------
#define numTimers 1
int16 VTimer0[numTimers];	// Virtual Timers slaved off CPU Timer 0
int16 VTimer1[numTimers];	// Virtual Timers slaved off CPU Timer 1
int16 VTimer2[numTimers];	// Virtual Timers slaved off CPU Timer 2
int16 SerialCommsTimer;
int16 CommsOKflg;

// Used for running BackGround in flash, and ISR in RAM
extern Uint16 *RamfuncsLoadStart, *RamfuncsLoadEnd, *RamfuncsRunStart;

// Used for ADC Configuration 
int ChSel[16]; 		// = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int TrigSel[16];	// = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int ACQPS[16];		// = {6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6};
// ---------------------------------- USER -----------------------------------------
int16 LLC_Enable;			// 1 = Enable, 0 = Disable
int16 SR_Enable;			// 1 = Enable, 0 = Disable
int16 Comp_Enable;			// 1 = Enable, 0 = Disable

int16 Pgain;				// PID P gain (Q10)
int16 Igain;				// PID I gain (Q10)
int16 Dgain;				// PID D gain (Q10)

int16 use_2P2Z;				// use 2P2Z coefficients instead of PID
int16 update_coeffs;		// flag used to trigger update of 2P2Z coefficients
long b2_coeff;
long b1_coeff;
long b0_coeff;
long a2_coeff;
long a1_coeff;
// ---------------------------- DPLIB Net Pointers ---------------------------------
// Declare net pointers that are used to connect the DP Lib Macros  here 

// ADC
extern volatile long *ADCDRV_1ch_Rlt7;	// Vout

// 2P2Z
extern volatile long *CNTL_2P2Z_Ref1;
extern volatile long *CNTL_2P2Z_Fdbk1;
extern volatile long *CNTL_2P2Z_Out1;
extern volatile long *CNTL_2P2Z_Coef1;

// PWM
extern volatile long *PWMDRV_LLC_ComplPairDB_Duty1;
extern volatile long *PWMDRV_LLC_ComplPairDB_Period1;
extern volatile long *PWMDRV_LLC_1ch_UpCntDB_Compl_Duty2;
extern volatile long *PWMDRV_LLC_1ch_UpCntDB_Compl_Period2;
extern volatile long *PWMDRV_LLC_1ch_UpCntDB_Duty3;
extern volatile long *PWMDRV_LLC_1ch_UpCntDB_Period3;

// ---------------------------- DPLIB Variables ---------------------------------
// Declare the net variables being used by the DP Lib Macro here 
volatile long Vout; 
volatile long Duty1; 
volatile long Duty2; 
volatile long Duty3; 
volatile long Period;

long Vset;			// Control loop target
long Min_Period;	// Minimum PWM period
long Max_Period;	// Maximum PWM period

int16 RED;			// Half-Bridge PWM1 Rising Edge Delay
int16 FED;			// Half-Bridge PWM1 Falling Edge Delay
int16 REM1;			// SR1 PWM2 Rising Edge Margin
int16 FEM1;			// SR1 PWM2 Falling Edge Margin
int16 REM2;			// SR2 PWM3 Rising Edge Margin
int16 FEM2;			// SR2 PWM3 Falling Edge Margin
int16 COMP1;		// SR1 Comparator Trip Value
int16 COMP2;		// SR2 Comparator Trip Value

#pragma DATA_SECTION(CNTL_2P2Z_CoefStruct1, "CNTL_2P2Z_Coef");
struct CNTL_2P2Z_CoefStruct CNTL_2P2Z_CoefStruct1;

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// VARIABLE DECLARATIONS - CCS WatchWindow / GUI support
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// -------------------------------- FRAMEWORK --------------------------------------

//GUI support variables
// sets a limit on the amount of external GUI controls - increase as necessary
int16 *varSetTxtList[16];	//16 textbox controlled variables
int16 *varSetBtnList[16];	//16 button controlled variables
int16 *varSetSldrList[16];	//16 slider controlled variables
int16 *varGetList[16];		//16 variables sendable to GUI
int16 *arrayGetList[16];	//16 arrays sendable to GUI	
int16 LedBlinkCnt;

// ---------------------------------- USER -----------------------------------------

int16 FlashID;

// Monitor ("Get")	// Display as:
int16 Gui_Vout;		// Q9
int16 Gui_Ipri;		// Q9	
int16 Gui_V_SR1;	// Q9
int16 Gui_V_SR2;	// Q9
int16 Gui_I_SR1;	// Q8
int16 Gui_I_SR2;	// Q8

// Configure ("Set")
int16 Gui_Vset;		// Q9

// History arrays are used for Running Average calculation (boxcar filter)
// Used for CCS display and GUI only, not part of control loop processing
Uint16 Hist_Vout[HistorySize];
Uint16 Hist_Ipri[HistorySize];
Uint16 Hist_V_SR1[HistorySize];
Uint16 Hist_V_SR2[HistorySize];
Uint16 Hist_I_SR1[HistorySize];
Uint16 Hist_I_SR2[HistorySize];

//Scaling Constants (values found via spreadsheet; exact value calibrated per board)
Uint16 K_Vout;	// 
Uint16 K_Ipri;	// 
Uint16 K_V_SR1;	// 
Uint16 K_V_SR2;	// 
Uint16 K_I_SR1;	// 
Uint16 K_I_SR2;	// 
Uint16 iK_Vset;	// 

// Variables for background support only (no need to access)
int16 i;						// common use incrementer
Uint32 HistPtr, temp_Scratch; 	// Temp here means Temporary


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// MAIN CODE - starts here
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
void main(void)
{
//=================================================================================
//	INITIALISATION - General
//=================================================================================

	// The DeviceInit() configures the clocks and pin mux registers 
	// The function is declared in HVLLC-DevInit_F2803/2x.c,
	// Please ensure/edit that all the desired components pin muxes 
	// are configured properly that clocks for the peripherals used
	// are enabled, for example the individual PWM clock must be enabled 
	// along with the Time Base Clock 

	DeviceInit();	// Device Life support & GPIO
	SCIA_Init();  	// Initalize the Serial Comms A peripheral		

//-------------------------------- FRAMEWORK --------------------------------------

// Only used if running from FLASH
// Note that the variable FLASH is defined by the compiler with -d FLASH

#ifdef FLASH		
// Copy time critical code and Flash setup code to RAM
// The  RamfuncsLoadStart, RamfuncsLoadEnd, and RamfuncsRunStart
// symbols are created by the linker. Refer to the linker files. 
	MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);

// Call Flash Initialization to setup flash waitstates
// This function must reside in RAM
	InitFlash();	// Call the flash wrapper init function
#endif //(FLASH)


// Timing sync for background loops
// Timer period definitions found in PeripheralHeaderIncludes.h
	CpuTimer0Regs.PRD.all =  mSec1;		// A tasks
	CpuTimer1Regs.PRD.all =  mSec10;	// B tasks
	CpuTimer2Regs.PRD.all =  mSec100;	// C tasks

// Tasks State-machine init
	Alpha_State_Ptr = &A0;
	A_Task_Ptr = &A1;
	B_Task_Ptr = &B1;
	C_Task_Ptr = &C1;

	for (i=0; i<numTimers; i++)
	{
		VTimer0[i] = 0;	
		VTimer1[i] = 0;
		VTimer2[i] = 0;
	}
	SerialCommsTimer = 0;
	CommsOKflg = 0;
	LedBlinkCnt = 5;

	for (i=0; i<16; i++)
	{
		ChSel[i] = 0;
		TrigSel[i] = 0;
		ACQPS[i] = 6;
	}

	for(i=0; i<HistorySize; i++)
	{
		Hist_Vout[i] = 0;
	}

// ---------------------------------- USER -----------------------------------------
//  put common initialization/variable definitions here
	Pgain = 200;		// Q10
	Igain = 1;			// Q10
	Dgain = 5;			// Q10

	use_2P2Z = 0;
	update_coeffs = 0;
	b2_coeff = _IQ26(0.35);
	b1_coeff = _IQ26(-1.45);
	b0_coeff = _IQ26(1.33);
	a2_coeff = _IQ26(-0.23);
	a1_coeff = _IQ26(1.23);

	K_Vout = 19439;		// 0.593 (Q15)
	K_Ipri = 19439;		// 0.593 (Q15) 
	K_V_SR1 = 19439;	// 0.593 (Q15)
	K_V_SR2 = 19439;	// 0.593 (Q15)
	K_I_SR1 = 16896;	// 0.516 (Q15)
	K_I_SR2 = 16896;	// 0.516 (Q15)
	iK_Vset = 27618;	// 1.686 (Q14)

	Gui_Vset = 0;
	Vset = 0;
	
	Duty1 = _IQ24(0.5);
	Duty2 = _IQ24(0.5);
	Duty3 = _IQ24(0.5);
	Period = _IQ14(550);
	Min_Period = _IQ14(MIN_PERIOD);
	Max_Period = _IQ14(MAX_PERIOD);

	RED = RisingEdgeDelay;
	FED = FallingEdgeDelay;
	REM1 = RisingEdgeMargin1;
	FEM1 = FallingEdgeMargin1;
	REM2 = RisingEdgeMargin2;
	FEM2 = FallingEdgeMargin2;
	COMP1 = CompTripLevel1;
	COMP2 = CompTripLevel2;
	
	LLC_Enable = DEMO_MODE;
	SR_Enable = DEMO_MODE;
	Comp_Enable = 0;

	CNTL_2P2Z_CoefStruct1.b2 = _IQ16(Dgain);
	CNTL_2P2Z_CoefStruct1.b1 = _IQ16(Igain - Pgain - Dgain - Dgain);
	CNTL_2P2Z_CoefStruct1.b0 = _IQ16(Pgain + Igain + Dgain);
	CNTL_2P2Z_CoefStruct1.a2 = _IQ26(0.0);
	CNTL_2P2Z_CoefStruct1.a1 = _IQ26(1.0);
	CNTL_2P2Z_CoefStruct1.max = Max_Period;
	CNTL_2P2Z_CoefStruct1.min = Min_Period;

//===============================================================================
//	INITIALISATION - GUI connections
//=================================================================================
// Use this section only if you plan to "Instrument" your application using the 
// Microsoft C# freeware GUI Template provided by TI

	FlashID = FLASHID;
	
	//"Set" variables
	//---------------------------------------
	// assign GUI variable Textboxes to desired "setable" parameter addresses
	varSetTxtList[0] = &Pgain;
	varSetTxtList[1] = &Igain;
	varSetTxtList[2] = &Dgain;
	varSetTxtList[3] = &RED;
	varSetTxtList[4] = &FED;
	varSetTxtList[5] = &REM1;
	varSetTxtList[6] = &FEM1;
	varSetTxtList[7] = &REM2;
	varSetTxtList[8] = &FEM2;
	varSetTxtList[9] = &COMP1;
	varSetTxtList[10] = &COMP2;

	// assign GUI Buttons to desired flag addresses
	varSetBtnList[0] = &LLC_Enable;
	varSetBtnList[1] = &SR_Enable;
	varSetBtnList[2] = &Comp_Enable;

	// assign GUI Sliders to desired "setable" parameter addresses
	varSetSldrList[0] = &Gui_Vset;

	//"Get" variables
	//---------------------------------------
	// assign a GUI "getable" parameter address
	varGetList[0] = &FlashID;
	varGetList[1] = &Gui_Vout;
	varGetList[2] = &Gui_I_SR1;
	varGetList[3] = &Gui_I_SR2;

	// assign a GUI "getable" parameter array address
//	arrayGetList[0] = &DBUFF1;  	//only need to set initial position of array,
//	arrayGetList[1] = &DBUFF2;		//  program will run through it accordingly

//==================================================================================
//	INCREMENTAL BUILD OPTIONS - NOTE: selected via HVLLC-Settings.h
//==================================================================================
// ---------------------------------- USER -----------------------------------------

#define		IpriR	AdcResult.ADCRESULT1		//Q12
#define		V_SR1R	AdcResult.ADCRESULT3		//Q12
#define		V_SR2R	AdcResult.ADCRESULT5		//Q12
#define		I_SR1R	AdcResult.ADCRESULT3		//Q12
#define		I_SR2R	AdcResult.ADCRESULT5		//Q12
#define		VoutR	AdcResult.ADCRESULT7		//Q12

	// Configure PWM1AB 
	PWM_ComplPairDB_CNF(1, MIN_PERIOD, 1, 0); 
	PWM_ComplPairDB_UpdateDB(1, RED, FED);
	// Configure PWM2A 
	PWM_1ch_UpCntDB_Compl_CNF(2, MIN_PERIOD, 0, 0); 
	PWM_1ch_UpCntDB_Compl_UpdateDB(2, REM1, FEM1); 
	// Configure PWM3A 
	PWM_1ch_UpCntDB_CNF(3, MIN_PERIOD, 0, 0); 
	PWM_1ch_UpCntDB_UpdateDB(3, REM2, FEM2); 

	// Configure PWM4 for use as ISR timer
	PWM_1ch_CNF(4, ISR_PERIOD, 1, 0);
	
	// ADC Channel Selection
	ChSel[0] = 9;		// Dummy read for first sample bug
	ChSel[1] = 9;		// B1 - Ipri

	ChSel[2] = 2;		// A2 - V_SR1 / I_SR1
	ChSel[3] = 2;		// A2 - V_SR1 / I_SR1

	ChSel[4] = 4;		// A4 - V_SR2 / I_SR2
	ChSel[5] = 4;		// A4 - V_SR2 / I_SR2

	ChSel[6] = 7;		// A7 - Vout
	ChSel[7] = 7;		// A7 - Vout

	// ADC Trigger Selection
	TrigSel[0] = ADCTRIG_EPWM1_SOCA;	// ePWM1, ADCSOCA
	TrigSel[1] = ADCTRIG_EPWM1_SOCA;	// ePWM1, ADCSOCA
	
	TrigSel[2] = ADCTRIG_EPWM2_SOCA;	// ePWM2, ADCSOCA
	TrigSel[3] = ADCTRIG_EPWM2_SOCA;	// ePWM2, ADCSOCA

	TrigSel[4] = ADCTRIG_EPWM3_SOCA;	// ePWM3, ADCSOCA
	TrigSel[5] = ADCTRIG_EPWM3_SOCA;	// ePWM3, ADCSOCA

   	TrigSel[6] = ADCTRIG_EPWM4_SOCA;	// ePWM4, ADCSOCA
   	TrigSel[7] = ADCTRIG_EPWM4_SOCA;	// ePWM4, ADCSOCA
   	
   	// Configure ADC 
	ADC_SOC_CNF(ChSel, TrigSel, ACQPS, 17, 0); 
	
	// Configure ePWMs to generate ADC SOC pulses
	EPwm1Regs.ETSEL.bit.SOCAEN = 1;					// Enable ePWM1 SOCA pulse
	EPwm1Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;		// SOCA from ePWM1 Zero event
	EPwm1Regs.ETPS.bit.SOCAPRD = ET_1ST;			// Trigger ePWM1 SOCA on every event

	EPwm2Regs.ETSEL.bit.SOCAEN = 1;					// Enable ePWM2 SOCA pulse
	EPwm2Regs.ETSEL.bit.SOCASEL = ET_CTRU_CMPB;		// SOCA from ePWM2 CMPB event
	EPwm2Regs.ETPS.bit.SOCAPRD = ET_1ST;			// Trigger ePWM2 SOCA on every event

	EPwm3Regs.ETSEL.bit.SOCAEN = 1;					// Enable ePWM3 SOCA pulse
	EPwm3Regs.ETSEL.bit.SOCASEL = ET_CTRU_CMPB;		// SOCA from ePWM3 CMPB event
	EPwm3Regs.ETPS.bit.SOCAPRD = ET_1ST;			// Trigger ePWM3 SOCA on every event

	EPwm4Regs.ETSEL.bit.SOCAEN = 1;					// Enable ePWM4 SOCA pulse
	EPwm4Regs.ETSEL.bit.SOCASEL = ET_CTR_ZERO;		// SOCA from ePWM4 Zero event
	EPwm4Regs.ETPS.bit.SOCAPRD = ET_1ST;			// Trigger ePWM4 SOCA on every event

	DPL_Init();
	
//----------------------------------------------------------------------
#if (INCR_BUILD == 1) 	// Open Loop
//----------------------------------------------------------------------

	// Lib Module connection to "nets" 
	//----------------------------------------
	// Connect the PWM Driver input to an input variable, Open Loop System
	ADCDRV_1ch_Rlt7 = &Vout;
	
	PWMDRV_LLC_ComplPairDB_Duty1 = &Duty1;
	PWMDRV_LLC_ComplPairDB_Period1 = &Period;
	PWMDRV_LLC_1ch_UpCntDB_Compl_Duty2 = &Duty2;
	PWMDRV_LLC_1ch_UpCntDB_Compl_Period2 = &Period;
	PWMDRV_LLC_1ch_UpCntDB_Duty3 = &Duty3;
	PWMDRV_LLC_1ch_UpCntDB_Period3 = &Period;
	
#endif // (INCR_BUILD == 1)

//----------------------------------------------------------------------
#if (INCR_BUILD == 2) 	// Closed Loop PID with SR timing based on Primary switches
//----------------------------------------------------------------------

	// Lib Module connection to "nets" 
	//----------------------------------------
	// Connect the PWM Driver input to an input variable, Open Loop System
	ADCDRV_1ch_Rlt7 = &Vout;
	
	CNTL_2P2Z_Ref1 = &Vset;
	CNTL_2P2Z_Fdbk1 = &Vout;
	CNTL_2P2Z_Out1 = &Period;
	CNTL_2P2Z_Coef1 = &CNTL_2P2Z_CoefStruct1.b2;

	PWMDRV_LLC_ComplPairDB_Duty1 = &Duty1;
	PWMDRV_LLC_ComplPairDB_Period1 = &Period;
	PWMDRV_LLC_1ch_UpCntDB_Compl_Duty2 = &Duty2;
	PWMDRV_LLC_1ch_UpCntDB_Compl_Period2 = &Period;
	PWMDRV_LLC_1ch_UpCntDB_Duty3 = &Duty3;
	PWMDRV_LLC_1ch_UpCntDB_Period3 = &Period;
	
#endif // (INCR_BUILD == 2)

//----------------------------------------------------------------------
#if (INCR_BUILD == 3) 	// Closed Loop PID with SR timing based on Current
//----------------------------------------------------------------------

	// Lib Module connection to "nets" 
	//----------------------------------------
	// Connect the PWM Driver input to an input variable, Open Loop System
	ADCDRV_1ch_Rlt7 = &Vout;
	
	CNTL_2P2Z_Ref1 = &Vset;
	CNTL_2P2Z_Fdbk1 = &Vout;
	CNTL_2P2Z_Out1 = &Period;
	CNTL_2P2Z_Coef1 = &CNTL_2P2Z_CoefStruct1.b2;

	PWMDRV_LLC_ComplPairDB_Duty1 = &Duty1;
	PWMDRV_LLC_ComplPairDB_Period1 = &Period;
	PWMDRV_LLC_1ch_UpCntDB_Compl_Duty2 = &Duty2;
	PWMDRV_LLC_1ch_UpCntDB_Compl_Period2 = &Period;
	PWMDRV_LLC_1ch_UpCntDB_Duty3 = &Duty3;
	PWMDRV_LLC_1ch_UpCntDB_Period3 = &Period;
		
#endif // (INCR_BUILD == 3)
//====================================================================================
// TRIP ZONES (TZ)
//====================================================================================

/*
	// Trip on Emulation Stop
	EALLOW;
	EPwm1Regs.TZSEL.bit.CBC6=0x1;
	EPwm1Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWMxA will go low 
	EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_LO; // EPWMxB will go low 
	EPwm2Regs.TZSEL.bit.CBC6=0x1;
	EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWMxA will go low 
	EPwm2Regs.TZCTL.bit.TZB = TZ_FORCE_LO; // EPWMxB will go low 
	EPwm3Regs.TZSEL.bit.CBC6=0x1;
	EPwm3Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWMxA will go low 
	EPwm3Regs.TZCTL.bit.TZB = TZ_FORCE_LO; // EPWMxB will go low 
	EDIS;
*/

#if (INCR_BUILD == 3) 	// Closed Loop PID with SR timing based on Current (and Primary switches)
// Configure SR current trips
	EALLOW;
	// Configure Analog Comparators
	Comp1Regs.COMPCTL.bit.SYNCSEL = 1;					// Sync with SYSCLK / use Qualification
	Comp1Regs.COMPCTL.bit.QUALSEL = 3;					// Require input be stable for 3 consecutive SYSCLKs 
	Comp1Regs.COMPCTL.bit.CMPINV = 1;					// Output Low when true
	Comp1Regs.COMPCTL.bit.COMPSOURCE = 0;				// Use internal DAC
	Comp1Regs.COMPCTL.bit.COMPDACEN = 1;				// Enable DAC
	Comp1Regs.DACVAL.bit.DACVAL = COMP1; 				// Trip Current = DACVAL/1023*82.5

	Comp2Regs.COMPCTL.bit.SYNCSEL = 1;					// Sync with SYSCLK / use Qualification
	Comp2Regs.COMPCTL.bit.QUALSEL = 3;					// Require input be stable for 3 consecutive SYSCLKs 
	Comp2Regs.COMPCTL.bit.CMPINV = 1;					// Output Low when true
	Comp2Regs.COMPCTL.bit.COMPSOURCE = 0;				// Use internal DAC
	Comp2Regs.COMPCTL.bit.COMPDACEN = 1;				// Enable DAC
	Comp2Regs.DACVAL.bit.DACVAL = COMP2; 				// Trip Current = DACVAL/1023*82.5

	// Configure ePWM Digital Compare modules
	EPwm2Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_COMP1OUT;  // DCAH = Comparator 1 output
	EPwm2Regs.TZDCSEL.bit.DCAEVT1 = TZ_DCAH_LOW; 		// DCAEVT1 on DCAH low (will become active as Comparator1 output goes low), DCAL = don't care
	EPwm2Regs.DCACTL.bit.EVT1SRCSEL = DC_EVT_FLT;		// DCAEVT1 filtered
	EPwm2Regs.DCACTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC; // Take async path
	EPwm2Regs.DCFCTL.bit.BLANKE = DC_BLANK_ENABLE;		// Enable Blanking window
	EPwm2Regs.DCFCTL.bit.SRCSEL = DC_SRC_DCAEVT1;		// Filter source = DCAEVT1
	EPwm2Regs.DCFCTL.bit.PULSESEL = DC_PULSESEL_ZERO;	// Filter start on TBCTR = ZERO
	EPwm2Regs.DCFOFFSET = 0;							// Filter offset
	EPwm2Regs.DCFWINDOW	= 0;							// Blanking window duration

	EPwm3Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_COMP2OUT;  // DCAH = Comparator 2 output
	EPwm3Regs.TZDCSEL.bit.DCAEVT1 = TZ_DCAH_LOW; 		// DCAEVT1 on DCAH low (will become active as Comparator2 output goes low), DCAL = don't care
	EPwm3Regs.DCACTL.bit.EVT1SRCSEL = DC_EVT_FLT;       // DCAEVT1 filtered
	EPwm3Regs.DCACTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC; // Take async path
	EPwm3Regs.DCFCTL.bit.BLANKE = DC_BLANK_ENABLE;		// Enable Blanking window
	EPwm3Regs.DCFCTL.bit.SRCSEL = DC_SRC_DCAEVT1;		// Filter source = DCAEVT1
	EPwm3Regs.DCFCTL.bit.PULSESEL = DC_PULSESEL_ZERO;	// Filter start on TBCTR = ZERO
	EPwm3Regs.DCFOFFSET = 0;							// Filter offset
	EPwm3Regs.DCFWINDOW	= 0;							// Blanking window duration

	// Configure ePWM Trip-Zone module	
	EPwm2Regs.TZCTL.bit.DCAEVT1 = TZ_FORCE_HI;				// EPWM2A will go HIGH

	EPwm3Regs.TZCTL.bit.DCAEVT1 = TZ_FORCE_HI;           	// EPWM3A will go HIGH

	EDIS;

#endif // (INCR_BUILD == 3)

//====================================================================================
// INTERRUPTS & ISR INITIALIZATION (best to run this section after other initialization)
//====================================================================================

//Also Set the appropriate # define's in the HVLLC-Settings.h 
//to enable interrupt management in the ISR
	EALLOW;
// Set up C28x Interrupt

// ADC EOC based ISR trigger
//	PieVectTable.ADCINT1 = &DPL_ISR;      		// Map Interrupt
//	PieCtrlRegs.PIEIER1.bit.INTx1 = 1;      	// PIE level enable, Grp1 / Int1, ADCINT1
//	AdcRegs.INTSEL1N2.bit.INT1SEL = 4;			// ADC Channel 4 EOC causes ADCInterrupt 1
//	IER |= M_INT1;                          	// Enable CPU INT1 group:

// PWM based ISR trigger
    PieVectTable.EPWM4_INT = &CNTL_ISR;      	// Map CNTL Interrupt
   	PieCtrlRegs.PIEIER3.bit.INTx4 = 1;      	// PIE level enable, Grp3 / Int1, ePWM4
	EPwm4Regs.CMPB = 50;						// ISR trigger point
   	EPwm4Regs.ETSEL.bit.INTSEL = ET_CTRU_CMPB; 	// INT on CompareB-Up event
   	EPwm4Regs.ETSEL.bit.INTEN = 1;              // Enable INT
    EPwm4Regs.ETPS.bit.INTPRD = ET_1ST;         // Generate INT on every 1st event

	PieVectTable.EPWM1_INT = &PWM_ISR;			// Map PWM Interrupt
   	PieCtrlRegs.PIEIER3.bit.INTx1 = 1;      	// PIE level enable, Grp3 / Int1, ePWM1
   	EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO; 	// INT on Counter-Zero event
   	EPwm1Regs.ETSEL.bit.INTEN = 1;              // Enable INT
    EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;         // Generate INT on every 1st event
	EDIS;      

	IER |= M_INT3;                          	// Enable CPU INT3 connected to EPWM1-6 INTs:
    
    EINT;                                   	// Enable Global interrupt INTM
    ERTM;                                   	// Enable Global realtime interrupt DBGM

//=================================================================================
//	BACKGROUND (BG) LOOP
//=================================================================================

//--------------------------------- FRAMEWORK -------------------------------------
	for(;;)  //infinite loop
	{
		// State machine entry & exit point
		//===========================================================
		(*Alpha_State_Ptr)();	// jump to an Alpha state (A0,B0,...)
		//===========================================================
	}
} //END MAIN CODE



//=================================================================================
//	STATE-MACHINE SEQUENCING AND SYNCRONIZATION
//=================================================================================

//--------------------------------- FRAMEWORK -------------------------------------
void A0(void)
{
	// loop rate synchronizer for A-tasks
	if(CpuTimer0Regs.TCR.bit.TIF == 1)
	{
		CpuTimer0Regs.TCR.bit.TIF = 1;	// clear flag

		//-----------------------------------------------------------
		(*A_Task_Ptr)();		// jump to an A Task (A1,A2,A3,...)
		//-----------------------------------------------------------

		VTimer0[0]++;			// virtual timer 0, instance 0 (spare)
	}

	Alpha_State_Ptr = &B0;		// Comment out to allow only A tasks
}

void B0(void)
{
	// loop rate synchronizer for B-tasks
	if(CpuTimer1Regs.TCR.bit.TIF == 1)
	{
		CpuTimer1Regs.TCR.bit.TIF = 1;				// clear flag

		//-----------------------------------------------------------
		(*B_Task_Ptr)();		// jump to a B Task (B1,B2,B3,...)
		//-----------------------------------------------------------
		VTimer1[0]++;			// virtual timer 1, instance 0 (spare)
	}

	Alpha_State_Ptr = &C0;		// Allow C state tasks
}

void C0(void)
{
	// loop rate synchronizer for C-tasks
	if(CpuTimer2Regs.TCR.bit.TIF == 1)
	{
		CpuTimer2Regs.TCR.bit.TIF = 1;				// clear flag

		//-----------------------------------------------------------
		(*C_Task_Ptr)();		// jump to a C Task (C1,C2,C3,...)
		//-----------------------------------------------------------
		VTimer2[0]++;			//virtual timer 2, instance 0 (spare)
	}

	Alpha_State_Ptr = &A0;	// Back to State A0
}


//=================================================================================
//	A - TASKS
//=================================================================================

//--------------------------------------------------------
void A1(void) 
//--------------------------------------------------------
{
	SerialHostComms();	//found in SciCommsGui.c

	// Channel On/Off control
	if(LLC_Enable == 1)
	{
		EPwm1Regs.AQCSFRC.bit.CSFA = 0;
		if (SR_Enable == 1)
		{
			EPwm2Regs.AQCSFRC.bit.CSFA = 0;
			EPwm3Regs.AQCSFRC.bit.CSFA = 0;
		}
		else
		{
			EPwm2Regs.AQCSFRC.bit.CSFA = 1;
			EPwm3Regs.AQCSFRC.bit.CSFA = 1;
		}
		
		if (Comp_Enable == 1)
		{
			EALLOW;
			EPwm2Regs.TZCTL.bit.DCAEVT1 = TZ_FORCE_HI;
			EPwm3Regs.TZCTL.bit.DCAEVT1 = TZ_FORCE_HI;
			EDIS;      
		}
		else
		{		
			EALLOW;
			EPwm2Regs.TZCTL.bit.DCAEVT1 = TZ_NO_CHANGE;
			EPwm3Regs.TZCTL.bit.DCAEVT1 = TZ_NO_CHANGE;
			EDIS;      
		}
	}
	else
	{
		EPwm1Regs.AQCSFRC.bit.CSFA = 1;
		EPwm2Regs.AQCSFRC.bit.CSFA = 1;
		EPwm3Regs.AQCSFRC.bit.CSFA = 1;
	}

	//-------------------
	//the next time CpuTimer0 'counter' reaches Period value go to A2
	A_Task_Ptr = &A1;
	//-------------------
}


//=================================================================================
//	B - TASKS
//=================================================================================

//----------------------------------------
void B1(void)
//----------------------------------------
{	
	HistPtr++;
	if (HistPtr >= HistorySize)	
		HistPtr = 0;

	// BoxCar Averages - Input Raw samples into BoxCar arrays
	//----------------------------------------------------------------
	Hist_Vout[HistPtr] = VoutR;
	Hist_Ipri[HistPtr] = IpriR;
	Hist_V_SR1[HistPtr] = V_SR1R;
	Hist_V_SR2[HistPtr] = V_SR2R;
	Hist_I_SR1[HistPtr] = I_SR1R;
	Hist_I_SR2[HistPtr] = I_SR2R;

	// Measurements
	//----------------------------------------------------------------
	temp_Scratch=0;
	for(i=0; i<HistorySize; i++)
		temp_Scratch = temp_Scratch + Hist_Vout[i];	//Q12 * 8 = Q15
	Gui_Vout = ((long)temp_Scratch*(long)K_Vout) >> 15;	//Q15*Q15 >> 15 = Q15

	temp_Scratch=0;
	for(i=0; i<HistorySize; i++)
		temp_Scratch = temp_Scratch + Hist_Ipri[i];	//Q12 * 8 = Q15
	Gui_Ipri = ((long)temp_Scratch*(long)K_Ipri) >> 15;	//Q15*Q15 >> 15 = Q15

	temp_Scratch=0;
	for(i=0; i<HistorySize; i++)
		temp_Scratch = temp_Scratch + Hist_V_SR1[i];	//Q12 * 8 = Q15
	Gui_V_SR1 = ((long)temp_Scratch*(long)K_V_SR1) >> 15;	//Q15*Q15 >> 15 = Q15

	temp_Scratch=0;
	for(i=0; i<HistorySize; i++)
		temp_Scratch = temp_Scratch + Hist_V_SR2[i];	//Q12 * 8 = Q15
	Gui_V_SR2 = ((long)temp_Scratch*(long)K_V_SR2) >> 15;	//Q15*Q15 >> 15 = Q15

	temp_Scratch=0;
	for(i=0; i<HistorySize; i++)
		temp_Scratch = temp_Scratch + Hist_I_SR1[i];	//Q12 * 8 = Q15
	Gui_I_SR1 = ((long)temp_Scratch*(long)K_I_SR1) >> 15;	//Q15*Q15 >> 15 = Q15

	temp_Scratch=0;
	for(i=0; i<HistorySize; i++)
		temp_Scratch = temp_Scratch + Hist_I_SR2[i];	//Q12 * 8 = Q15
	Gui_I_SR2 = ((long)temp_Scratch*(long)K_I_SR2) >> 15;	//Q15*Q15 >> 15 = Q15

	//Multiply with longs to get proper result then shift by 14 to turn it back into an int16
	Vset = ((long)Gui_Vset*(long)iK_Vset) >> 5;

	//-----------------
	//the next time CpuTimer1 'counter' reaches Period value go to B2
	B_Task_Ptr = &B2;	
	//-----------------
}

//----------------------------------------
void B2(void) // Blink LED on the controlCARD
//----------------------------------------
{
	if(LedBlinkCnt==0)
		{
			GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;	//turn on/off LD3 on the controlCARD
			LedBlinkCnt=5;
		}
	else
			LedBlinkCnt--;
			
	//-----------------
	//the next time CpuTimer1 'counter' reaches Period value go to B1
	B_Task_Ptr = &B1;
	//-----------------
}


//=================================================================================
//	C - TASKS
//=================================================================================

//------------------------------------------------------
void C1(void)  // Update Coefficients	 
//------------------------------------------------------
{
	// Update PWM1
	PWM_ComplPairDB_UpdateDB(1, RED, FED);
	// Update PWM2A
	PWM_1ch_UpCntDB_Compl_UpdateDB(2, REM1, FEM1); 
	// Update PWM3A
	PWM_1ch_UpCntDB_UpdateDB(3, REM2, FEM2); 

	// Configure Comp1 Trip Level
	Comp1Regs.DACVAL.bit.DACVAL = COMP1;
	// Configure Comp2 Trip Level
	Comp2Regs.DACVAL.bit.DACVAL = COMP2;

	if (use_2P2Z)
	{
		if (update_coeffs)
		{
			CNTL_2P2Z_CoefStruct1.b2 = b2_coeff;
			CNTL_2P2Z_CoefStruct1.b1 = b1_coeff;
			CNTL_2P2Z_CoefStruct1.b0 = b0_coeff;
			CNTL_2P2Z_CoefStruct1.a2 = a2_coeff;
			CNTL_2P2Z_CoefStruct1.a1 = a1_coeff;
			CNTL_2P2Z_CoefStruct1.max = Max_Period;
			CNTL_2P2Z_CoefStruct1.min = Min_Period;
			update_coeffs=0;
		}
	}
	else
	{
		CNTL_2P2Z_CoefStruct1.b2 = _IQ16(Dgain);
		CNTL_2P2Z_CoefStruct1.b1 = _IQ16(Igain - Pgain - Dgain - Dgain);
		CNTL_2P2Z_CoefStruct1.b0 = _IQ16(Pgain + Igain + Dgain);
		CNTL_2P2Z_CoefStruct1.a2 = _IQ26(0.0);
		CNTL_2P2Z_CoefStruct1.a1 = _IQ26(1.0);
		CNTL_2P2Z_CoefStruct1.max = Max_Period;
		CNTL_2P2Z_CoefStruct1.min = Min_Period;		
	}

	if ((DEMO_MODE)&&(Gui_Vout > _IQ9(11.0)))
	{
		Gui_Vset = _IQ9(12.1);
	}
		
	//-----------------
	//the next time CpuTimer2 'counter' reaches Period value go to C2
	C_Task_Ptr = &C1;	
	//-----------------
}
