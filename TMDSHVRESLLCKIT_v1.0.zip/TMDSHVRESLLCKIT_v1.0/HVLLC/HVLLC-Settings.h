//----------------------------------------------------------------------------------
//	FILE:			HVLLC-Settings.h
//
//	Description:    This file contains the definitions for this project, and is 
//					linked to both HVLLC-Main.c and HVLLC-DPL-ISR.asm 
//
//	Type: 			Device Independent
//
//----------------------------------------------------------------------------------
//  Copyright Texas Instruments � 2010
//----------------------------------------------------------------------------------
//  Revision History:
//----------------------------------------------------------------------------------
//  Date	  | Description / Status
//----------------------------------------------------------------------------------
// 9 April 2010 - MB
//----------------------------------------------------------------------------------

#ifndef _PROJSETTINGS_H
#define _PROJSETTINGS_H

//**********************************************************************************
//  NOTE: WHEN CHANGING THIS FILE PLEASE REBUILD ALL
//**********************************************************************************

//==================================================================================
// Incremental Build options for System check-out
//==================================================================================
// BUILD 1 	Open Loop 
// BUILD 2 	Closed Loop PID with SR timing based on Primary switches
// BUILD 3 	Closed Loop PID with SR timing based on Current (and Primary switches)

#define INCR_BUILD 3
		
//==================================================================================
// System Settings
//----------------------------------------------------------------------------------
//Add any system specific setting below
#define HistorySize 8
//#define DLOG_SIZE   200

#define MIN_PERIOD 350
#define MAX_PERIOD 650
#define ISR_PERIOD 600

#define RisingEdgeDelay 	15		// 3 cycles == 50ns delay
#define FallingEdgeDelay 	15		// 3 cycles == 50ns delay
#define RisingEdgeMargin1 	25
#define FallingEdgeMargin1 	65
#define RisingEdgeMargin2 	25
#define FallingEdgeMargin2 	65
#define CompTripLevel1		150
#define CompTripLevel2		150

#define DACTRIP	150

#define FLASHID 0x2002

#define DEMO_MODE 0					// Set to 1 to enable Auto-Start for Demo purposes
//==================================================================================
// Interrupt Framework options
//==================================================================================

#define EPWMn_DPL_ISR	1	// for EPWM triggered ISR set as 1
#define ADC_DPL_ISR	    0	// for ADC triggered ISR set as 1 

#endif //_PROJSETTINGS_H

